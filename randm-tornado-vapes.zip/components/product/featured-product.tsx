import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Check, Star } from "lucide-react"
import { formatPrice } from "@/lib/utils"

export function FeaturedProduct() {
  // Featured product data
  const product = {
    name: "RANDM TORNADO 7000",
    description:
      "Genießen Sie bis zu 7000 Züge mit intensivem Geschmack und einer wiederaufladbaren Batterie, die für eine langanhaltende Dampferfahrung sorgt. Dieses Gerät ist ideal für Dampfer, die es nicht nur auf die Anzahl der Züge, sondern auch auf Langlebigkeit und komfortable Nutzung setzen.",
    price: 29.99,
    comparePrice: 59.98,
    discount: 50,
    image: "/products/randm-tornado-7000.jpg",
    slug: "randm-tornado-7000",
    features: ["Bis zu 7000 Züge", "Wiederaufladbare Batterie", "Intensiver Geschmack", "Kompaktes Design"],
  }

  return (
    <div className="grid md:grid-cols-2 gap-8 items-center">
      <div className="order-2 md:order-1">
        <div className="flex items-center mb-2">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="h-5 w-5 fill-amber-400 text-amber-400" />
            ))}
          </div>
          <span className="ml-2 text-sm text-gray-600">128 Bewertungen</span>
        </div>
        <h3 className="text-2xl font-bold mb-4">{product.name}</h3>
        <p className="text-gray-600 mb-6">{product.description}</p>

        <ul className="space-y-2 mb-6">
          {product.features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>

        <div className="flex items-center mb-6">
          <div className="text-2xl font-bold text-amber-500">{formatPrice(product.price)}</div>
          {product.comparePrice && (
            <div className="ml-2 text-lg text-gray-500 line-through">{formatPrice(product.comparePrice)}</div>
          )}
          {product.discount && (
            <div className="ml-3 bg-red-500 text-white text-sm px-2 py-1 rounded">-{product.discount}%</div>
          )}
        </div>

        <div className="flex flex-wrap gap-3">
          <Button asChild className="bg-amber-500 hover:bg-amber-600 text-white">
            <Link href={`/produkte/${product.slug}`}>Jetzt kaufen</Link>
          </Button>
          <Button variant="outline">Mehr erfahren</Button>
        </div>
      </div>
      <div className="order-1 md:order-2 flex justify-center">
        <div className="bg-gray-200 rounded-full p-8 w-64 h-64 flex items-center justify-center relative overflow-hidden group">
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            width={200}
            height={200}
            className="w-full h-auto transition-transform duration-300 group-hover:scale-110"
          />
          <div className="absolute top-4 right-4 bg-amber-500 text-white text-xs font-bold px-2 py-1 rounded-full">
            Bestseller
          </div>
        </div>
      </div>
    </div>
  )
}
