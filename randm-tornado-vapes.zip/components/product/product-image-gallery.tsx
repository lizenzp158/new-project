"use client"

import { useState } from "react"
import Image from "next/image"

interface ProductImageGalleryProps {
  images: string[]
  productName: string
}

export function ProductImageGallery({ images, productName }: ProductImageGalleryProps) {
  const [selectedImage, setSelectedImage] = useState(0)

  return (
    <div className="space-y-4">
      <div className="bg-gray-100 rounded-lg p-4 flex items-center justify-center relative overflow-hidden">
        {images[selectedImage] && (
          <Image
            src={images[selectedImage] || "/placeholder.svg"}
            alt={`${productName} - Bild ${selectedImage + 1}`}
            width={500}
            height={500}
            className="max-w-full h-auto object-contain"
            priority
          />
        )}
      </div>

      {images.length > 1 && (
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {images.map((image, index) => (
            <button
              key={index}
              onClick={() => setSelectedImage(index)}
              className={`relative border-2 rounded overflow-hidden flex-shrink-0 w-20 h-20 ${
                selectedImage === index ? "border-amber-500" : "border-transparent"
              }`}
              aria-label={`Bild ${index + 1} anzeigen`}
            >
              <Image
                src={image || "/placeholder.svg"}
                alt={`${productName} - Thumbnail ${index + 1}`}
                fill
                className="object-cover"
                sizes="80px"
              />
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
