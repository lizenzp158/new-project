import Link from "next/link"
import { Facebook, Instagram, Twitter } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-zinc-900 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Randm Tornado Vapes</h3>
            <p className="text-gray-300 mb-4">Qualitätsprodukte für ein besseres Dampferlebnis.</p>
            <div className="flex space-x-4">
              <Link href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                <Facebook className="h-5 w-5 text-gray-300 hover:text-white" />
              </Link>
              <Link href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                <Instagram className="h-5 w-5 text-gray-300 hover:text-white" />
              </Link>
              <Link href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
                <Twitter className="h-5 w-5 text-gray-300 hover:text-white" />
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Informationen</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/uber-uns" className="text-gray-300 hover:text-white">
                  Über Uns
                </Link>
              </li>
              <li>
                <Link href="/versand" className="text-gray-300 hover:text-white">
                  Versand & Lieferung
                </Link>
              </li>
              <li>
                <Link href="/agb" className="text-gray-300 hover:text-white">
                  AGB
                </Link>
              </li>
              <li>
                <Link href="/datenschutz" className="text-gray-300 hover:text-white">
                  Datenschutz
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Kundenservice</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/kontakt" className="text-gray-300 hover:text-white">
                  Kontakt
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-gray-300 hover:text-white">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/rueckgabe" className="text-gray-300 hover:text-white">
                  Rückgabe & Erstattung
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Kontakt</h3>
            <address className="not-italic text-gray-300">
              <p>
                Email:{" "}
                <a href="mailto:support@randmtornadovapes.de" className="hover:text-white">
                  support@randmtornadovapes.de
                </a>
              </p>
              <p>
                Telefon:{" "}
                <a href="tel:+491234567890" className="hover:text-white">
                  +49 123 456789
                </a>
              </p>
              <p>Adresse: Musterstraße 123, 12345 Berlin</p>
            </address>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-400 text-sm">
          <p>© {new Date().getFullYear()} Randm Tornado Vapes. Alle Rechte vorbehalten.</p>
          <p className="mt-2">
            Diese Website ist nur für Personen über 18 Jahren bestimmt. Der Verkauf von Nikotinprodukten an Personen
            unter 18 Jahren ist verboten.
          </p>
        </div>
      </div>
    </footer>
  )
}
