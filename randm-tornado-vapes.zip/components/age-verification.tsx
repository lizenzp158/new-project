"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

export function AgeVerification() {
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const verified = localStorage.getItem("age-verified")
    if (!verified) {
      setOpen(true)
    }
  }, [])

  const handleVerify = () => {
    localStorage.setItem("age-verified", "true")
    setOpen(false)
  }

  const handleReject = () => {
    window.location.href = "https://www.google.com"
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Altersverifikation</DialogTitle>
          <DialogDescription>
            Diese Website enthält Produkte, die nur für Personen über 18 Jahren bestimmt sind.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <p>Bitte bestätigen Sie, dass Sie mindestens 18 Jahre alt sind, um fortzufahren.</p>
        </div>
        <DialogFooter className="flex flex-col sm:flex-row sm:justify-between gap-2">
          <Button variant="outline" onClick={handleReject}>
            Ich bin unter 18
          </Button>
          <Button className="bg-amber-500 hover:bg-amber-600" onClick={handleVerify}>
            Ich bin über 18
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
