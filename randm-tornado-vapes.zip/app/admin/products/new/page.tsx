"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { ImageUpload } from "@/components/admin/image-upload"
import { toast } from "@/components/ui/use-toast"
import { Trash } from "lucide-react"

export default function NewProductPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [productData, setProductData] = useState({
    name: "",
    slug: "",
    description: "",
    price: "",
    comparePrice: "",
    category: "",
    images: [],
    features: [""],
    inStock: true,
    stockQuantity: "100",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setProductData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (checked: boolean) => {
    setProductData((prev) => ({ ...prev, inStock: checked }))
  }

  const handleFeatureChange = (index: number, value: string) => {
    const newFeatures = [...productData.features]
    newFeatures[index] = value
    setProductData((prev) => ({ ...prev, features: newFeatures }))
  }

  const addFeature = () => {
    setProductData((prev) => ({ ...prev, features: [...prev.features, ""] }))
  }

  const removeFeature = (index: number) => {
    const newFeatures = [...productData.features]
    newFeatures.splice(index, 1)
    setProductData((prev) => ({ ...prev, features: newFeatures }))
  }

  const handleImagesChange = (images: string[]) => {
    setProductData((prev) => ({ ...prev, images }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Generate slug if empty
      let slug = productData.slug
      if (!slug) {
        slug = productData.name
          .toLowerCase()
          .replace(/\s+/g, "-")
          .replace(/[^\w-]+/g, "")
      }

      const response = await fetch("/api/admin/products", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...productData,
          slug,
          price: Number.parseFloat(productData.price),
          comparePrice: productData.comparePrice ? Number.parseFloat(productData.comparePrice) : null,
          stockQuantity: Number.parseInt(productData.stockQuantity),
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to create product")
      }

      toast({
        title: "Produkt erstellt",
        description: "Das Produkt wurde erfolgreich erstellt.",
      })

      router.push("/admin/products")
    } catch (error) {
      console.error("Error creating product:", error)
      toast({
        title: "Fehler",
        description: "Das Produkt konnte nicht erstellt werden.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Neues Produkt</h1>
      </div>

      <form onSubmit={handleSubmit}>
        <Tabs defaultValue="general" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="general">Allgemein</TabsTrigger>
            <TabsTrigger value="images">Bilder</TabsTrigger>
            <TabsTrigger value="features">Eigenschaften</TabsTrigger>
          </TabsList>

          <TabsContent value="general">
            <Card>
              <CardContent className="pt-6">
                <div className="grid gap-6">
                  <div className="grid gap-3">
                    <Label htmlFor="name">Name</Label>
                    <Input id="name" name="name" value={productData.name} onChange={handleChange} required />
                  </div>

                  <div className="grid gap-3">
                    <Label htmlFor="slug">Slug (URL)</Label>
                    <Input
                      id="slug"
                      name="slug"
                      value={productData.slug}
                      onChange={handleChange}
                      placeholder="Wird automatisch generiert, wenn leer"
                    />
                  </div>

                  <div className="grid gap-3">
                    <Label htmlFor="description">Beschreibung</Label>
                    <Textarea
                      id="description"
                      name="description"
                      value={productData.description}
                      onChange={handleChange}
                      rows={5}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div className="grid gap-3">
                      <Label htmlFor="price">Preis (€)</Label>
                      <Input
                        id="price"
                        name="price"
                        type="number"
                        step="0.01"
                        value={productData.price}
                        onChange={handleChange}
                        required
                      />
                    </div>

                    <div className="grid gap-3">
                      <Label htmlFor="comparePrice">Vergleichspreis (€)</Label>
                      <Input
                        id="comparePrice"
                        name="comparePrice"
                        type="number"
                        step="0.01"
                        value={productData.comparePrice}
                        onChange={handleChange}
                      />
                    </div>
                  </div>

                  <div className="grid gap-3">
                    <Label htmlFor="category">Kategorie</Label>
                    <Input
                      id="category"
                      name="category"
                      value={productData.category}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div className="grid gap-3">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="inStock">Auf Lager</Label>
                        <Switch id="inStock" checked={productData.inStock} onCheckedChange={handleSwitchChange} />
                      </div>
                    </div>

                    <div className="grid gap-3">
                      <Label htmlFor="stockQuantity">Lagerbestand</Label>
                      <Input
                        id="stockQuantity"
                        name="stockQuantity"
                        type="number"
                        value={productData.stockQuantity}
                        onChange={handleChange}
                        disabled={!productData.inStock}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="images">
            <Card>
              <CardContent className="pt-6">
                <ImageUpload images={productData.images} onChange={handleImagesChange} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="features">
            <Card>
              <CardContent className="pt-6">
                <div className="grid gap-6">
                  <div className="flex justify-between items-center">
                    <Label>Produkteigenschaften</Label>
                    <Button type="button" variant="outline" onClick={addFeature}>
                      Eigenschaft hinzufügen
                    </Button>
                  </div>

                  {productData.features.map((feature, index) => (
                    <div key={index} className="flex gap-3">
                      <Input
                        value={feature}
                        onChange={(e) => handleFeatureChange(index, e.target.value)}
                        placeholder={`Eigenschaft ${index + 1}`}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => removeFeature(index)}
                        disabled={productData.features.length <= 1}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-6 flex justify-end gap-3">
          <Button variant="outline" type="button" onClick={() => router.back()}>
            Abbrechen
          </Button>
          <Button type="submit" className="bg-amber-500 hover:bg-amber-600" disabled={isSubmitting}>
            {isSubmitting ? "Wird gespeichert..." : "Produkt speichern"}
          </Button>
        </div>
      </form>
    </div>
  )
}
