import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ProductCategoryGrid } from "@/components/product/product-category-grid"
import { FeaturedProduct } from "@/components/product/featured-product"
import { BenefitSection } from "@/components/sections/benefit-section"
import { NewsletterSection } from "@/components/sections/newsletter-section"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Randm Tornado Vapes - Premium Vaping Produkte",
  description:
    "Entdecken Sie hochwertige Vaping-Produkte von Randm Tornado. Große Auswahl, schneller Versand und exzellenter Kundenservice.",
  openGraph: {
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Randm Tornado Vapes",
      },
    ],
  },
}

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="py-12 md:py-20 bg-gradient-to-r from-zinc-100 to-zinc-200">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-5xl font-bold mb-6">Premium Vaping Produkte</h1>
          <p className="text-lg md:text-xl text-gray-700 mb-8 max-w-2xl mx-auto">
            Entdecken Sie die Randm Tornado Serie mit intensivem Geschmack und langanhaltender Dampferfahrung
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button asChild size="lg" className="bg-amber-500 hover:bg-amber-600 text-white">
              <Link href="/produkte">Jetzt einkaufen</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="/gebrauchsanweisung">Gebrauchsanweisung</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Product Categories */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-4">Unsere Produkte</h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Wählen Sie aus unserer breiten Palette an hochwertigen Vaping-Produkten für ein optimales Dampferlebnis
          </p>
          <ProductCategoryGrid />
        </div>
      </section>

      {/* Featured Product */}
      <section className="py-16 bg-zinc-100">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">Unser Bestseller</h2>
          <FeaturedProduct />
        </div>
      </section>

      {/* Benefits Section */}
      <BenefitSection />

      {/* Newsletter Section */}
      <NewsletterSection />
    </div>
  )
}
