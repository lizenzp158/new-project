import Link from "next/link"

interface ProductCategoryProps {
  name: string
  slug: string
  image: string
}

export default function ProductCategory({ name, slug, image }: ProductCategoryProps) {
  return (
    <Link href={`/produkte/${slug}`} className="group">
      <div className="bg-gray-200 rounded-full p-4 flex items-center justify-center aspect-square overflow-hidden transition-all group-hover:shadow-md">
        <div className="bg-amber-400 text-white font-medium text-center p-4 rounded-full w-full h-full flex items-center justify-center">
          <span className="text-sm md:text-base">{name}</span>
        </div>
      </div>
    </Link>
  )
}
