import { notFound } from "next/navigation"
import type { Metadata } from "next"
import { products } from "@/lib/product-data"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Check, Star } from "lucide-react"
import ProductCard from "@/components/product/product-card"
import { formatPrice } from "@/lib/utils"
import { ProductReviews } from "@/components/product/product-reviews"
import { ProductTabs } from "@/components/product/product-tabs"
import { ProductImageGallery } from "@/components/product/product-image-gallery"

interface ProductPageProps {
  params: {
    slug: string
  }
}

export async function generateMetadata({ params }: ProductPageProps): Promise<Metadata> {
  const product = products.find((p) => p.slug === params.slug)

  if (!product) {
    return {
      title: "Produkt nicht gefunden | Randm Tornado Vapes",
      description: "Das gesuchte Produkt wurde nicht gefunden.",
    }
  }

  return {
    title: `${product.name} | Randm Tornado Vapes`,
    description: product.description,
    openGraph: {
      title: product.name,
      description: product.description,
      type: "product",
      images: [
        {
          url: product.image,
          width: 800,
          height: 600,
          alt: product.name,
        },
      ],
    },
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const product = products.find((p) => p.slug === params.slug)

  if (!product) {
    notFound()
  }

  // Get related products (excluding current product)
  const relatedProducts = products.filter((p) => p.id !== product.id).slice(0, 3)

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="grid md:grid-cols-2 gap-12 mb-16">
        <div>
          <ProductImageGallery images={product.images || [product.image]} productName={product.name} />
        </div>

        <div>
          <div className="flex items-center mb-2">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 fill-amber-400 text-amber-400" />
              ))}
            </div>
            <span className="ml-2 text-sm text-gray-600">128 Bewertungen</span>
          </div>

          <h1 className="text-3xl font-bold mb-4">{product.name}</h1>

          <div className="flex items-center mb-6">
            <div className="text-2xl font-bold text-amber-500">{formatPrice(product.price)}</div>
            {product.comparePrice && product.comparePrice > product.price && (
              <>
                <div className="ml-2 text-lg text-gray-500 line-through">{formatPrice(product.comparePrice)}</div>
                <div className="ml-3 bg-red-500 text-white text-sm px-2 py-1 rounded">-{product.discount}%</div>
              </>
            )}
          </div>

          <div className="mb-6">
            <p className="text-gray-700 mb-4">{product.description}</p>

            <div className="mt-6">
              <h3 className="font-semibold mb-2">Eigenschaften:</h3>
              <ul className="space-y-2">
                {product.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <Button size="lg" className="bg-amber-500 hover:bg-amber-600">
              <ShoppingCart className="h-5 w-5 mr-2" />
              In den Warenkorb
            </Button>
            <Button variant="outline" size="lg">
              Sofort kaufen
            </Button>
          </div>

          <div className="p-4 bg-gray-100 rounded-lg">
            <p className="text-sm">
              <strong>Versand:</strong> Kostenloser Versand für Bestellungen über €50. Lieferung innerhalb von 2-4
              Werktagen.
            </p>
          </div>
        </div>
      </div>

      <ProductTabs description={product.description} />

      <ProductReviews />

      {relatedProducts.length > 0 && (
        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-6">Das könnte Ihnen auch gefallen</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {relatedProducts.map((product) => (
              <ProductCard
                key={product.id}
                id={product.id}
                name={product.name}
                price={product.price}
                comparePrice={product.comparePrice}
                discount={product.discount}
                image={product.image}
                slug={product.slug}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
