"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"

export function NewsletterSection() {
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    toast({
      title: "Erfolgreich abonniert!",
      description: "Vielen Dank für Ihr Interesse an unserem Newsletter.",
    })

    setEmail("")
    setIsSubmitting(false)
  }

  return (
    <section className="py-16 bg-zinc-800 text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-6">Bleiben Sie auf dem Laufenden</h2>
        <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
          Abonnieren Sie unseren Newsletter und erhalten Sie exklusive Angebote und Neuigkeiten direkt in Ihr Postfach.
        </p>
        <form onSubmit={handleSubmit} className="max-w-md mx-auto flex flex-col sm:flex-row gap-3">
          <Input
            type="email"
            placeholder="Ihre E-Mail-Adresse"
            className="flex-1 px-4 py-3 rounded-md text-black"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Button type="submit" className="bg-amber-500 hover:bg-amber-600 text-white" disabled={isSubmitting}>
            {isSubmitting ? "Wird abonniert..." : "Abonnieren"}
          </Button>
        </form>
      </div>
    </section>
  )
}
