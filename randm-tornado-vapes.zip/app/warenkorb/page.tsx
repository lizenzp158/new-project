import type { Metadata } from "next"
import CartContent from "@/components/cart/cart-content"

export const metadata: Metadata = {
  title: "Warenkorb | Randm Tornado Vapes",
  description: "Überprüfen Sie Ihren Warenkorb und fahren Sie mit dem Checkout fort.",
  robots: {
    index: false,
    follow: true,
  },
}

export default function CartPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">Warenkorb</h1>
      <CartContent />
    </div>
  )
}
