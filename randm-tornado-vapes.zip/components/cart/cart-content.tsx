"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Minus, Plus, Trash2 } from "lucide-react"
import { formatPrice } from "@/lib/utils"

// Mock cart data for demonstration
const initialCartItems = [
  {
    id: 1,
    name: "RANDM TORNADO 7000",
    price: 29.99,
    quantity: 2,
    image: "/products/randm-tornado-7000.jpg",
  },
  {
    id: 2,
    name: "RANDM TORNADO 10000",
    price: 34.99,
    quantity: 1,
    image: "/products/randm-tornado-10000.jpg",
  },
]

export default function CartContent() {
  const [cartItems, setCartItems] = useState(initialCartItems)

  const updateQuantity = (id: number, newQuantity: number) => {
    if (newQuantity < 1) return

    setCartItems(cartItems.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item)))
  }

  const removeItem = (id: number) => {
    setCartItems(cartItems.filter((item) => item.id !== id))
  }

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const shipping = subtotal > 50 ? 0 : 4.99
  const total = subtotal + shipping

  return (
    <>
      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          <h2 className="text-2xl font-medium mb-4">Ihr Warenkorb ist leer</h2>
          <p className="text-gray-600 mb-8">Fügen Sie einige Produkte hinzu, um fortzufahren</p>
          <Button asChild className="bg-amber-500 hover:bg-amber-600">
            <Link href="/produkte">Weiter einkaufen</Link>
          </Button>
        </div>
      ) : (
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Produkt
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Preis
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Menge
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Gesamt
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"></th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {cartItems.map((item) => (
                    <tr key={item.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-16 w-16 flex-shrink-0 mr-4">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              width={64}
                              height={64}
                              className="h-16 w-16 rounded object-cover"
                            />
                          </div>
                          <div>
                            <div className="text-sm font-medium text-gray-900">{item.name}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{formatPrice(item.price)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center border rounded-md">
                          <button
                            className="px-2 py-1 text-gray-600 hover:text-gray-900"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            aria-label="Menge verringern"
                          >
                            <Minus className="h-4 w-4" />
                          </button>
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => updateQuantity(item.id, Number.parseInt(e.target.value) || 1)}
                            className="w-12 text-center border-0 focus:ring-0"
                            aria-label="Menge"
                          />
                          <button
                            className="px-2 py-1 text-gray-600 hover:text-gray-900"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            aria-label="Menge erhöhen"
                          >
                            <Plus className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {formatPrice(item.price * item.quantity)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => removeItem(item.id)}
                          className="text-red-600 hover:text-red-900"
                          aria-label="Artikel entfernen"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-8 flex justify-between items-center">
              <Button variant="outline" asChild>
                <Link href="/produkte">Weiter einkaufen</Link>
              </Button>

              <div className="flex items-center space-x-4">
                <Input type="text" placeholder="Gutscheincode" className="w-40" />
                <Button variant="outline">Anwenden</Button>
              </div>
            </div>
          </div>

          <div>
            <div className="border rounded-lg p-6">
              <h2 className="text-lg font-bold mb-4">Zusammenfassung</h2>

              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Zwischensumme</span>
                  <span>{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Versand</span>
                  <span>{shipping === 0 ? "Kostenlos" : formatPrice(shipping)}</span>
                </div>
                <div className="border-t pt-4 flex justify-between font-bold">
                  <span>Gesamtsumme</span>
                  <span>{formatPrice(total)}</span>
                </div>
              </div>

              <Button asChild className="w-full mt-6 bg-amber-500 hover:bg-amber-600">
                <Link href="/checkout">Zur Kasse</Link>
              </Button>

              <div className="mt-6 text-sm text-gray-500">
                <p>Wir akzeptieren:</p>
                <p className="mt-2">Banküberweisung (Vorkasse)</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
