import type { Metadata } from "next"
import { products } from "@/lib/product-data"
import ProductCard from "@/components/product/product-card"
import { ProductFilter } from "@/components/product/product-filter"

export const metadata: Metadata = {
  title: "Produkte | Randm Tornado Vapes",
  description:
    "Entdecken Sie unser Sortiment an hochwertigen Vaping-Produkten. Von Einweg-Vapes bis zu wiederaufladbaren Geräten.",
}

export default function ProductsPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">Alle Produkte</h1>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="w-full lg:w-1/4">
          <ProductFilter />
        </div>

        <div className="w-full lg:w-3/4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <ProductCard
                key={product.id}
                id={product.id}
                name={product.name}
                price={product.price}
                comparePrice={product.comparePrice}
                discount={product.discount}
                image={product.image}
                slug={product.slug}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
