import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Header from "@/components/layout/header"
import Footer from "@/components/layout/footer"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import { AgeVerification } from "@/components/age-verification"
import { GoogleAnalytics } from "@/components/analytics"
import { Suspense } from "react"

const inter = Inter({ subsets: ["latin"] })

// Default metadata that will be used across the site
export const metadata: Metadata = {
  title: {
    default: "Randm Tornado Vapes - Premium Vaping Produkte",
    template: "%s | Randm Tornado Vapes",
  },
  description:
    "Kaufen Sie die besten Vaping-Produkte bei Randm Tornado Vapes. Schneller Versand, Qualitätsprodukte und hervorragender Kundenservice.",
  keywords: [
    "vapes",
    "randm tornado",
    "e-zigaretten",
    "vaping produkte",
    "einweg vapes",
    "randm tornado 7000",
    "randm tornado 35000",
  ],
  authors: [{ name: "Randm Tornado Vapes" }],
  creator: "Randm Tornado Vapes",
  publisher: "Randm Tornado Vapes",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://randmtornadovapes.de"),
  alternates: {
    canonical: "/",
    languages: {
      "de-DE": "/",
    },
  },
  openGraph: {
    type: "website",
    locale: "de_DE",
    url: "https://randmtornadovapes.de",
    title: "Randm Tornado Vapes - Premium Vaping Produkte",
    description: "Kaufen Sie die besten Vaping-Produkte bei Randm Tornado Vapes.",
    siteName: "Randm Tornado Vapes",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="de">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light">
          <div className="flex min-h-screen flex-col">
            <Suspense>
              <Header />
            </Suspense>
            <main className="flex-1">{children}</main>
            <Footer />
          </div>
          <Toaster />
          <AgeVerification />
          <GoogleAnalytics gaId="G-1Q36V1WRW1" />
        </ThemeProvider>
      </body>
    </html>
  )
}
