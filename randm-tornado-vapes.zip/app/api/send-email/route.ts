import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, message, orderNumber } = body

    // Here you would normally use an email service like Nodemailer, SendGrid, etc.
    // For demonstration purposes, we're just logging the data
    console.log("Email data:", { name, email, message, orderNumber })

    // Simulate sending email
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error sending email:", error)
    return NextResponse.json({ error: "Failed to send email" }, { status: 500 })
  }
}
