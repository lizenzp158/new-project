import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ShoppingCart } from "lucide-react"
import { formatPrice } from "@/lib/utils"

interface ProductCardProps {
  id: number
  name: string
  price: number
  comparePrice?: number
  discount?: number
  image: string
  slug: string
}

export default function ProductCard({ id, name, price, comparePrice, discount, image, slug }: ProductCardProps) {
  return (
    <div className="border rounded-lg overflow-hidden group hover:shadow-md transition-shadow">
      <Link href={`/produkte/${slug}`} className="block">
        <div className="aspect-square bg-gray-100 relative overflow-hidden">
          <Image
            src={image || "/placeholder.svg"}
            alt={name}
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            className="object-contain group-hover:scale-105 transition-transform duration-300"
          />
          {discount && discount > 0 && (
            <div className="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              -{discount}%
            </div>
          )}
        </div>
      </Link>
      <div className="p-4">
        <Link href={`/produkte/${slug}`} className="block">
          <h3 className="font-medium text-lg mb-2 line-clamp-2 h-14 hover:text-amber-600 transition-colors">{name}</h3>
        </Link>
        <div className="flex items-center mt-2">
          <span className="text-lg font-bold text-amber-500">{formatPrice(price)}</span>
          {comparePrice && comparePrice > price && (
            <span className="ml-2 text-sm text-gray-500 line-through">{formatPrice(comparePrice)}</span>
          )}
        </div>
        <div className="mt-4">
          <Button className="w-full bg-amber-500 hover:bg-amber-600">
            <ShoppingCart className="h-4 w-4 mr-2" />
            In den Warenkorb
          </Button>
        </div>
      </div>
    </div>
  )
}
