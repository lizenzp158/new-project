import type { Metadata } from "next"
import CheckoutForm from "@/components/checkout/checkout-form"

export const metadata: Metadata = {
  title: "Checkout | Randm Tornado Vapes",
  description: "Schließen Sie Ihre Bestellung ab und bezahlen Sie sicher.",
  robots: {
    index: false,
    follow: true,
  },
}

export default function CheckoutPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">Checkout</h1>
      <CheckoutForm />
    </div>
  )
}
