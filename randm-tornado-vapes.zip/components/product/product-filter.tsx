"use client"

import { useState } from "react"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export function ProductFilter() {
  const [priceRange, setPriceRange] = useState([0, 100])

  return (
    <div className="bg-white p-4 rounded-lg border">
      <h2 className="font-semibold text-lg mb-4">Filter</h2>

      <Accordion type="multiple" defaultValue={["category", "price"]}>
        <AccordionItem value="category">
          <AccordionTrigger>Kategorien</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox id="all" />
                <Label htmlFor="all">Alle Produkte</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="tornado" />
                <Label htmlFor="tornado">Randm Tornado</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="shisha" />
                <Label htmlFor="shisha">Randm Shisha</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="alfakher" />
                <Label htmlFor="alfakher">Al Fakher</Label>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="price">
          <AccordionTrigger>Preis</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <Slider defaultValue={[0, 100]} max={100} step={1} value={priceRange} onValueChange={setPriceRange} />
              <div className="flex items-center justify-between">
                <span>{priceRange[0]}€</span>
                <span>{priceRange[1]}€</span>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="features">
          <AccordionTrigger>Eigenschaften</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox id="rechargeable" />
                <Label htmlFor="rechargeable">Wiederaufladbar</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="disposable" />
                <Label htmlFor="disposable">Einweg</Label>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <Button className="w-full mt-6 bg-zinc-800 hover:bg-zinc-700">Filter anwenden</Button>
    </div>
  )
}
