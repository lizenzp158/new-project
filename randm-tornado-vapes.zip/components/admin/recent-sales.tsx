import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export function RecentSales() {
  return (
    <div className="space-y-8">
      <div className="flex items-center">
        <Avatar className="h-9 w-9">
          <AvatarFallback>MK</AvatarFallback>
        </Avatar>
        <div className="ml-4 space-y-1">
          <p className="text-sm font-medium leading-none">Max Krause</p>
          <p className="text-sm text-muted-foreground">max.krause@example.com</p>
        </div>
        <div className="ml-auto font-medium">+€129.00</div>
      </div>
      <div className="flex items-center">
        <Avatar className="h-9 w-9">
          <AvatarFallback>LM</AvatarFallback>
        </Avatar>
        <div className="ml-4 space-y-1">
          <p className="text-sm font-medium leading-none">Laura Müller</p>
          <p className="text-sm text-muted-foreground">laura.mueller@example.com</p>
        </div>
        <div className="ml-auto font-medium">+€39.00</div>
      </div>
      <div className="flex items-center">
        <Avatar className="h-9 w-9">
          <AvatarFallback>TS</AvatarFallback>
        </Avatar>
        <div className="ml-4 space-y-1">
          <p className="text-sm font-medium leading-none">Thomas Schmidt</p>
          <p className="text-sm text-muted-foreground">thomas.schmidt@example.com</p>
        </div>
        <div className="ml-auto font-medium">+€299.00</div>
      </div>
      <div className="flex items-center">
        <Avatar className="h-9 w-9">
          <AvatarFallback>SB</AvatarFallback>
        </Avatar>
        <div className="ml-4 space-y-1">
          <p className="text-sm font-medium leading-none">Sarah Becker</p>
          <p className="text-sm text-muted-foreground">sarah.becker@example.com</p>
        </div>
        <div className="ml-auto font-medium">+€99.00</div>
      </div>
      <div className="flex items-center">
        <Avatar className="h-9 w-9">
          <AvatarFallback>JW</AvatarFallback>
        </Avatar>
        <div className="ml-4 space-y-1">
          <p className="text-sm font-medium leading-none">Jan Wagner</p>
          <p className="text-sm text-muted-foreground">jan.wagner@example.com</p>
        </div>
        <div className="ml-auto font-medium">+€39.00</div>
      </div>
    </div>
  )
}
