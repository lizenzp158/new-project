"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { BarChart, Box, Home, Package, Settings, ShoppingCart, Users, FileText, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
// Authentication will be implemented in a later phase

const navItems = [
  {
    title: "Dashboard",
    href: "/admin",
    icon: Home,
  },
  {
    title: "Produkte",
    href: "/admin/products",
    icon: Package,
  },
  {
    title: "Bestellungen",
    href: "/admin/orders",
    icon: ShoppingCart,
  },
  {
    title: "Kunden",
    href: "/admin/customers",
    icon: Users,
  },
  {
    title: "Kategorien",
    href: "/admin/categories",
    icon: Box,
  },
  {
    title: "Seiten",
    href: "/admin/pages",
    icon: FileText,
  },
  {
    title: "Analytik",
    href: "/admin/analytics",
    icon: BarChart,
  },
  {
    title: "Einstellungen",
    href: "/admin/settings",
    icon: Settings,
  },
]

export default function AdminSidebar() {
  const pathname = usePathname()

  return (
    <div className="hidden border-r bg-gray-100/40 lg:block lg:w-64">
      <div className="flex h-full max-h-screen flex-col gap-2">
        <div className="flex h-14 items-center border-b px-4">
          <Link href="/admin" className="flex items-center gap-2 font-semibold">
            <Package className="h-6 w-6" />
            <span>Admin Dashboard</span>
          </Link>
        </div>
        <div className="flex-1 overflow-auto py-2">
          <nav className="grid items-start px-2 text-sm font-medium">
            {navItems.map((item, index) => (
              <Link
                key={index}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 transition-all",
                  pathname === item.href
                    ? "bg-gray-200 text-gray-900"
                    : "text-gray-500 hover:text-gray-900 hover:bg-gray-100",
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.title}
              </Link>
            ))}
            <Button
              variant="ghost"
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-500 hover:text-gray-900 hover:bg-gray-100 justify-start text-sm font-medium mt-4"
              onClick={() => (window.location.href = "/")}
            >
              <LogOut className="h-4 w-4" />
              Abmelden
            </Button>
          </nav>
        </div>
      </div>
    </div>
  )
}
