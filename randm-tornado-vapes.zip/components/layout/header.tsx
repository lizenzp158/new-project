"use client"

import Link from "next/link"
import Image from "next/image"
import { useState } from "react"
import { Search, User, ShoppingCart, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

export default function Header() {
  const pathname = usePathname()
  const [isSearchOpen, setIsSearchOpen] = useState(false)

  const navigation = [
    { name: "Startseite", href: "/" },
    { name: "Produkte", href: "/produkte" },
    { name: "Gebrauchsanweisung", href: "/gebrauchsanweisung" },
    { name: "Über Uns", href: "/uber-uns" },
    { name: "Kontakt", href: "/kontakt" },
  ]

  return (
    <header className="w-full">
      <div className="bg-black text-white py-2 text-center">
        <p className="text-sm md:text-base">🔥 Sommerschlussverkauf- 50% Rabatt 🔥</p>
      </div>
      <div className="bg-zinc-900 py-4">
        <div className="container mx-auto px-4 flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="mr-8" aria-label="Randm Tornado Vapes Startseite">
              <Image src="/logo.svg" alt="Randm Tornado Vapes" width={120} height={60} className="h-14 w-auto" />
            </Link>

            <nav className="hidden md:flex space-x-6">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "text-white hover:text-amber-300 transition",
                    pathname === item.href && "text-amber-400 font-medium",
                  )}
                >
                  {item.name}
                </Link>
              ))}
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="text-white" onClick={() => setIsSearchOpen(!isSearchOpen)}>
              <Search className="h-5 w-5" />
              <span className="sr-only">Suche</span>
            </Button>
            <Link href="/konto" aria-label="Mein Konto">
              <Button variant="ghost" size="icon" className="text-white">
                <User className="h-5 w-5" />
                <span className="sr-only">Konto</span>
              </Button>
            </Link>
            <Link href="/warenkorb" aria-label="Warenkorb anzeigen">
              <Button variant="ghost" size="icon" className="text-white relative">
                <ShoppingCart className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 bg-amber-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  0
                </span>
                <span className="sr-only">Warenkorb</span>
              </Button>
            </Link>

            <Sheet>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon" className="text-white">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Menü</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[250px] sm:w-[300px]">
                <nav className="flex flex-col space-y-4 mt-8">
                  {navigation.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className={cn("text-lg font-medium", pathname === item.href && "text-amber-500 font-semibold")}
                    >
                      {item.name}
                    </Link>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>

      {/* Search Bar - Conditionally rendered */}
      {isSearchOpen && (
        <div className="bg-zinc-800 py-3">
          <div className="container mx-auto px-4">
            <form className="flex items-center">
              <input
                type="search"
                placeholder="Suchen Sie nach Produkten..."
                className="w-full px-4 py-2 rounded-l-md focus:outline-none"
                aria-label="Produkte suchen"
              />
              <Button type="submit" className="bg-amber-500 hover:bg-amber-600 rounded-l-none">
                <Search className="h-5 w-5" />
                <span className="sr-only">Suchen</span>
              </Button>
            </form>
          </div>
        </div>
      )}
    </header>
  )
}
