import Link from "next/link"
import { productCategories } from "@/lib/product-data"

export function ProductCategoryGrid() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
      {productCategories.map((category) => (
        <Link
          key={category.id}
          href={`/produkte/${category.slug}`}
          className="group transition-transform hover:scale-105"
        >
          <div className="bg-gray-100 rounded-full p-4 flex items-center justify-center aspect-square overflow-hidden transition-all group-hover:shadow-md">
            <div className="bg-amber-400 text-white font-medium text-center p-4 rounded-full w-full h-full flex items-center justify-center">
              <span className="text-sm md:text-base">{category.name}</span>
            </div>
          </div>
        </Link>
      ))}
    </div>
  )
}
