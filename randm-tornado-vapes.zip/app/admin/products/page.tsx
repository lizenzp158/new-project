import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DataTable } from "@/components/admin/data-table"
import { Plus } from "lucide-react"
import { getProducts } from "@/lib/products"
import { productColumns } from "@/components/admin/product-columns"

export default async function ProductsPage() {
  const products = await getProducts()

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Produkte</h1>
        <Button asChild className="bg-amber-500 hover:bg-amber-600">
          <Link href="/admin/products/new">
            <Plus className="mr-2 h-4 w-4" /> Neues Produkt
          </Link>
        </Button>
      </div>

      <div className="mb-6">
        <Input placeholder="Produkte suchen..." className="max-w-sm" />
      </div>

      <DataTable columns={productColumns} data={products} />
    </div>
  )
}
