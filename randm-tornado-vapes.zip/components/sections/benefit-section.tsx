import { Check, Clock, Truck } from "lucide-react"

export function BenefitSection() {
  const benefits = [
    {
      icon: Check,
      title: "Qualitätsprodukte",
      description:
        "Alle unsere Produkte werden strengen Qualitätskontrollen unterzogen, um ein optimales Dampferlebnis zu gewährleisten.",
    },
    {
      icon: Truck,
      title: "Schneller Versand",
      description:
        "Wir versenden alle Bestellungen innerhalb von 24 Stunden, damit Sie Ihre Produkte so schnell wie möglich erhalten.",
    },
    {
      icon: Clock,
      title: "Kundenservice",
      description: "Unser freundliches Team steht Ihnen bei Fragen oder Problemen jederzeit zur Verfügung.",
    },
  ]

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">Warum Randm Tornado Vapes?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="text-center p-6 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
            >
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <benefit.icon className="h-8 w-8 text-amber-500" />
              </div>
              <h3 className="text-xl font-semibold mb-3">{benefit.title}</h3>
              <p className="text-gray-600">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
