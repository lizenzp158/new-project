"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { formatPrice } from "@/lib/utils"

// Mock cart data for demonstration
const cartItems = [
  {
    id: 1,
    name: "RANDM TORNADO 7000",
    price: 29.99,
    quantity: 2,
    image: "/products/randm-tornado-7000.jpg",
  },
  {
    id: 2,
    name: "RANDM TORNADO 10000",
    price: 34.99,
    quantity: 1,
    image: "/products/randm-tornado-10000.jpg",
  },
]

export default function CheckoutForm() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    postalCode: "",
    country: "Deutschland",
    paymentMethod: "bank-transfer",
    notes: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleRadioChange = (value: string) => {
    setFormData((prev) => ({ ...prev, paymentMethod: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Here you would normally process the order
    setTimeout(() => {
      router.push("/danke")
    }, 1500)
  }

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const shipping = subtotal > 50 ? 0 : 4.99
  const total = subtotal + shipping

  return (
    <div className="grid md:grid-cols-3 gap-8">
      <div className="md:col-span-2">
        <form onSubmit={handleSubmit}>
          <div className="border rounded-lg p-6 mb-8">
            <h2 className="text-xl font-bold mb-4">Persönliche Informationen</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <Label htmlFor="firstName">Vorname</Label>
                <Input id="firstName" name="firstName" value={formData.firstName} onChange={handleChange} required />
              </div>
              <div>
                <Label htmlFor="lastName">Nachname</Label>
                <Input id="lastName" name="lastName" value={formData.lastName} onChange={handleChange} required />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email">E-Mail</Label>
                <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
              </div>
              <div>
                <Label htmlFor="phone">Telefon</Label>
                <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} required />
              </div>
            </div>
          </div>

          <div className="border rounded-lg p-6 mb-8">
            <h2 className="text-xl font-bold mb-4">Lieferadresse</h2>

            <div className="space-y-4">
              <div>
                <Label htmlFor="address">Adresse</Label>
                <Input id="address" name="address" value={formData.address} onChange={handleChange} required />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-1">
                  <Label htmlFor="postalCode">PLZ</Label>
                  <Input
                    id="postalCode"
                    name="postalCode"
                    value={formData.postalCode}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="md:col-span-1">
                  <Label htmlFor="city">Stadt</Label>
                  <Input id="city" name="city" value={formData.city} onChange={handleChange} required />
                </div>
                <div className="md:col-span-1">
                  <Label htmlFor="country">Land</Label>
                  <Input id="country" name="country" value={formData.country} onChange={handleChange} required />
                </div>
              </div>
            </div>
          </div>

          <div className="border rounded-lg p-6 mb-8">
            <h2 className="text-xl font-bold mb-4">Zahlungsmethode</h2>

            <RadioGroup value={formData.paymentMethod} onValueChange={handleRadioChange} className="space-y-4">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="bank-transfer" id="bank-transfer" />
                <Label htmlFor="bank-transfer">Banküberweisung (Vorkasse)</Label>
              </div>
              <div className="text-sm text-gray-500 ml-6">
                <p>
                  Nach Abschluss der Bestellung erhalten Sie unsere Kontodaten und sollten den Betrag innerhalb von 7
                  Tagen per Überweisung begleichen.
                </p>
                <p className="mt-2 font-medium">
                  Bitte beachten Sie: Ihre Bestellung wird erst nach Eingang der Zahlung versandt.
                </p>
              </div>
            </RadioGroup>
          </div>

          <div className="border rounded-lg p-6 mb-8">
            <h2 className="text-xl font-bold mb-4">Bestellnotizen (optional)</h2>

            <Textarea
              id="notes"
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              placeholder="Besondere Anweisungen für Ihre Bestellung"
              className="h-32"
            />
          </div>

          <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600" disabled={isSubmitting}>
            {isSubmitting ? "Bestellung wird bearbeitet..." : "Bestellung abschließen"}
          </Button>
        </form>
      </div>

      <div>
        <div className="border rounded-lg p-6 sticky top-6">
          <h2 className="text-lg font-bold mb-4">Ihre Bestellung</h2>

          <div className="space-y-4 mb-6">
            {cartItems.map((item) => (
              <div key={item.id} className="flex justify-between">
                <div className="flex items-center">
                  <Image
                    src={item.image || "/placeholder.svg?height=40&width=40&query=vape device"}
                    alt={item.name}
                    width={40}
                    height={40}
                    className="h-10 w-10 rounded object-cover mr-3"
                  />
                  <div>
                    <div className="text-sm font-medium">{item.name}</div>
                    <div className="text-xs text-gray-500">
                      {item.quantity} x {formatPrice(item.price)}
                    </div>
                  </div>
                </div>
                <div className="text-sm font-medium">{formatPrice(item.price * item.quantity)}</div>
              </div>
            ))}
          </div>

          <div className="border-t pt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Zwischensumme</span>
              <span>{formatPrice(subtotal)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Versand</span>
              <span>{shipping === 0 ? "Kostenlos" : formatPrice(shipping)}</span>
            </div>
            <div className="border-t pt-2 flex justify-between font-bold">
              <span>Gesamtsumme</span>
              <span>{formatPrice(total)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
