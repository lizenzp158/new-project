"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ProductTabsProps {
  description: string
}

export function ProductTabs({ description }: ProductTabsProps) {
  return (
    <Tabs defaultValue="description" className="mt-12">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="description">Beschreibung</TabsTrigger>
        <TabsTrigger value="specifications">Spezifikationen</TabsTrigger>
        <TabsTrigger value="shipping">Versand & Rückgabe</TabsTrigger>
      </TabsList>
      <TabsContent value="description" className="p-4 border rounded-b-lg">
        <div className="prose max-w-none">
          <p>{description}</p>
        </div>
      </TabsContent>
      <TabsContent value="specifications" className="p-4 border rounded-b-lg">
        <div className="prose max-w-none">
          <table className="w-full">
            <tbody>
              <tr>
                <td className="font-semibold pr-4 py-2">Typ</td>
                <td>Einweg E-Zigarette</td>
              </tr>
              <tr>
                <td className="font-semibold pr-4 py-2">Batterie</td>
                <td>Wiederaufladbar</td>
              </tr>
              <tr>
                <td className="font-semibold pr-4 py-2">Nikotingehalt</td>
                <td>20mg/ml (2%)</td>
              </tr>
              <tr>
                <td className="font-semibold pr-4 py-2">Geschmacksrichtungen</td>
                <td>Verschiedene verfügbar</td>
              </tr>
              <tr>
                <td className="font-semibold pr-4 py-2">Hergestellt in</td>
                <td>China</td>
              </tr>
            </tbody>
          </table>
        </div>
      </TabsContent>
      <TabsContent value="shipping" className="p-4 border rounded-b-lg">
        <div className="prose max-w-none">
          <h3 className="text-lg font-semibold mb-2">Versandinformationen</h3>
          <p>Wir versenden alle Bestellungen innerhalb von 24 Stunden nach Zahlungseingang.</p>
          <ul className="list-disc pl-5 my-2">
            <li>Kostenloser Versand für Bestellungen über 50€</li>
            <li>Standardversand: 4,99€ (2-4 Werktage)</li>
            <li>Express-Versand: 9,99€ (1-2 Werktage)</li>
          </ul>

          <h3 className="text-lg font-semibold mt-4 mb-2">Rückgaberichtlinie</h3>
          <p>
            Wir akzeptieren Rücksendungen innerhalb von 14 Tagen nach Erhalt der Ware, sofern diese ungeöffnet und
            unbeschädigt ist.
          </p>
        </div>
      </TabsContent>
    </Tabs>
  )
}
