"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash, Upload } from "lucide-react"

interface ImageUploadProps {
  images: string[]
  onChange: (images: string[]) => void
}

export function ImageUpload({ images, onChange }: ImageUploadProps) {
  const [isUploading, setIsUploading] = useState(false)

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    setIsUploading(true)

    try {
      // In a real implementation, you would upload to a storage service
      // For this demo, we'll simulate the upload with a timeout
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Create object URLs for the files (in a real app, these would be URLs from your storage service)
      const newImages = Array.from(files).map((file) => URL.createObjectURL(file))
      onChange([...images, ...newImages])
    } catch (error) {
      console.error("Error uploading images:", error)
    } finally {
      setIsUploading(false)
    }
  }

  const removeImage = (index: number) => {
    const newImages = [...images]
    newImages.splice(index, 1)
    onChange(newImages)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Produktbilder</h3>
        <div>
          <Input
            type="file"
            accept="image/*"
            multiple
            onChange={handleUpload}
            className="hidden"
            id="image-upload"
            disabled={isUploading}
          />
          <label htmlFor="image-upload">
            <Button variant="outline" className="cursor-pointer" asChild>
              <span>
                <Upload className="mr-2 h-4 w-4" />
                Bilder hochladen
              </span>
            </Button>
          </label>
        </div>
      </div>

      {isUploading && <p className="text-sm text-muted-foreground">Bilder werden hochgeladen...</p>}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {images.map((image, index) => (
          <div key={index} className="relative group">
            <div className="aspect-square rounded-md overflow-hidden border">
              <Image
                src={image || "/placeholder.svg"}
                alt={`Product image ${index + 1}`}
                width={200}
                height={200}
                className="w-full h-full object-cover"
              />
            </div>
            <Button
              variant="destructive"
              size="icon"
              className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={() => removeImage(index)}
            >
              <Trash className="h-4 w-4" />
            </Button>
          </div>
        ))}

        {images.length === 0 && (
          <div className="aspect-square rounded-md border border-dashed flex items-center justify-center">
            <p className="text-sm text-muted-foreground">Keine Bilder</p>
          </div>
        )}
      </div>
    </div>
  )
}
