"use client"

import { useState } from "react"
import { Star, ThumbsUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

export function ProductReviews() {
  const [showAllReviews, setShowAllReviews] = useState(false)

  // Mock review data
  const reviews = [
    {
      id: 1,
      author: "Thomas M.",
      rating: 5,
      date: "15.04.2023",
      title: "Hervorragendes Produkt",
      content:
        "Ich bin sehr zufrieden mit diesem Produkt. Die Batterie hält lange und der Geschmack ist intensiv. Kann ich nur empfehlen!",
      helpful: 12,
    },
    {
      id: 2,
      author: "Sarah K.",
      rating: 4,
      date: "03.03.2023",
      title: "Gutes Preis-Leistungs-Verhältnis",
      content:
        "Für den Preis bekommt man ein wirklich gutes Produkt. Einziger Kritikpunkt ist die etwas kurze Lebensdauer, aber ansonsten top!",
      helpful: 8,
    },
    {
      id: 3,
      author: "Michael B.",
      rating: 5,
      date: "22.02.2023",
      title: "Bester Vape auf dem Markt",
      content:
        "Habe schon viele verschiedene Modelle ausprobiert, aber dieses ist mit Abstand das Beste. Geschmack und Dampfentwicklung sind hervorragend.",
      helpful: 15,
    },
    {
      id: 4,
      author: "Lisa W.",
      rating: 3,
      date: "10.01.2023",
      title: "Okay, aber nicht perfekt",
      content:
        "Das Produkt funktioniert gut, aber ich hatte mir etwas mehr erhofft. Die Batterie entlädt sich schneller als angegeben.",
      helpful: 5,
    },
  ]

  const displayedReviews = showAllReviews ? reviews : reviews.slice(0, 2)

  // Calculate rating statistics
  const averageRating = reviews.reduce((acc, review) => acc + review.rating, 0) / reviews.length
  const ratingCounts = [0, 0, 0, 0, 0]
  reviews.forEach((review) => ratingCounts[review.rating - 1]++)

  return (
    <div className="mt-16">
      <h2 className="text-2xl font-bold mb-6">Kundenbewertungen</h2>

      <div className="grid md:grid-cols-3 gap-8 mb-8">
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <div className="text-4xl font-bold mb-2">{averageRating.toFixed(1)}</div>
          <div className="flex justify-center mb-2">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-5 w-5 ${i < Math.round(averageRating) ? "fill-amber-400 text-amber-400" : "text-gray-300"}`}
              />
            ))}
          </div>
          <div className="text-sm text-gray-500">Basierend auf {reviews.length} Bewertungen</div>
        </div>

        <div className="md:col-span-2">
          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map((rating) => (
              <div key={rating} className="flex items-center">
                <div className="w-12 text-sm">
                  {rating} Stern{rating !== 1 ? "e" : ""}
                </div>
                <Progress value={(ratingCounts[rating - 1] / reviews.length) * 100} className="h-2 w-full mx-2" />
                <div className="w-12 text-sm text-right">{ratingCounts[rating - 1]}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {displayedReviews.map((review) => (
          <div key={review.id} className="border-b pb-6">
            <div className="flex justify-between items-start mb-2">
              <div>
                <div className="font-semibold">{review.title}</div>
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${i < review.rating ? "fill-amber-400 text-amber-400" : "text-gray-300"}`}
                    />
                  ))}
                </div>
              </div>
              <div className="text-sm text-gray-500">
                {review.author} • {review.date}
              </div>
            </div>
            <p className="text-gray-700 mb-2">{review.content}</p>
            <Button variant="ghost" size="sm" className="text-gray-500 text-sm">
              <ThumbsUp className="h-4 w-4 mr-1" />
              Hilfreich ({review.helpful})
            </Button>
          </div>
        ))}
      </div>

      {reviews.length > 2 && (
        <Button variant="outline" className="mt-6" onClick={() => setShowAllReviews(!showAllReviews)}>
          {showAllReviews ? "Weniger anzeigen" : `Alle ${reviews.length} Bewertungen anzeigen`}
        </Button>
      )}
    </div>
  )
}
