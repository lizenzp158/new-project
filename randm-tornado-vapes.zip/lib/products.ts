import prisma from "@/lib/db"

export async function getProducts() {
  try {
    const products = await prisma.product.findMany({
      orderBy: {
        createdAt: "desc",
      },
    })

    return products
  } catch (error) {
    console.error("Database Error:", error)
    throw new Error("Failed to fetch products")
  }
}

export async function getProductBySlug(slug: string) {
  try {
    const product = await prisma.product.findUnique({
      where: {
        slug,
      },
    })

    return product
  } catch (error) {
    console.error("Database Error:", error)
    throw new Error("Failed to fetch product")
  }
}

export async function createProduct(data: any) {
  try {
    const product = await prisma.product.create({
      data,
    })

    return product
  } catch (error) {
    console.error("Database Error:", error)
    throw new Error("Failed to create product")
  }
}

export async function updateProduct(id: string, data: any) {
  try {
    const product = await prisma.product.update({
      where: {
        id,
      },
      data,
    })

    return product
  } catch (error) {
    console.error("Database Error:", error)
    throw new Error("Failed to update product")
  }
}

export async function deleteProduct(id: string) {
  try {
    await prisma.product.delete({
      where: {
        id,
      },
    })

    return { success: true }
  } catch (error) {
    console.error("Database Error:", error)
    throw new Error("Failed to delete product")
  }
}
