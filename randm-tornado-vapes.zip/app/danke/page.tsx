import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Vielen Dank für Ihre Bestellung | Randm Tornado Vapes",
  description: "Ihre Bestellung wurde erfolgreich aufgenommen. Wir werden sie so schnell wie möglich bearbeiten.",
  robots: {
    index: false,
    follow: true,
  },
}

export default function ThankYouPage() {
  return (
    <div className="container mx-auto px-4 py-16 text-center">
      <div className="max-w-md mx-auto">
        <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-6" />

        <h1 className="text-3xl font-bold mb-4">Vielen Dank für Ihre Bestellung!</h1>

        <p className="text-gray-600 mb-8">
          Ihre Bestellung wurde erfolgreich aufgenommen. Eine Bestätigungs-E-Mail wurde an Ihre E-Mail-Adresse gesendet.
        </p>

        <div className="bg-gray-100 rounded-lg p-6 mb-8">
          <h2 className="font-semibold mb-2">Bestellnummer: #RT12345</h2>
          <p className="text-sm text-gray-600">Bitte bewahren Sie diese Bestellnummer für Rückfragen auf.</p>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-lg p-6 mb-8 text-left">
          <h2 className="font-bold mb-4">Zahlungsinformationen</h2>

          <p className="mb-4">Bitte überweisen Sie den Gesamtbetrag auf das folgende Konto:</p>

          <div className="space-y-2 mb-4">
            <p>
              <strong>Zahlungsempfänger:</strong> chisom joel
            </p>
            <p>
              <strong>IBAN:</strong> GB04 CLJU04 1307 6721 3462
            </p>
            <p>
              <strong>BIC:</strong> CLJUGB21XXX
            </p>
            <p>
              <strong>Verwendungszweck:</strong> "RT12345"
            </p>
          </div>

          <p className="text-sm">
            Bitte beachten Sie: Dieses Konto unterstützt nur Zahlungen über SEPA- und SEPA-Instant-Zahlungssysteme aus
            EWR-Regionen.
          </p>

          <div className="mt-4 text-sm text-amber-700">
            <p>
              Bitte beachten Sie: Ihre Bestellung wird erst nach Eingang der Zahlung versandt. Nach Eingang Ihrer
              Zahlung wird Ihr Paket für den Versand vorbereitet und schnellstens verschickt.
            </p>
            <p className="mt-2">
              Nach der Zahlung senden Sie bitte auch den Zahlungsnachweis per E-Mail an support@randmtornadovapes.de, um
              Ihre Bestellung zu bestätigen.
            </p>
          </div>
        </div>

        <div className="space-y-4 text-left mb-8">
          <h3 className="font-semibold">Nächste Schritte:</h3>
          <ol className="list-decimal list-inside space-y-2 text-gray-600">
            <li>Sie erhalten in Kürze eine Bestätigungs-E-Mail mit den Zahlungsdetails.</li>
            <li>Bitte überweisen Sie den Betrag innerhalb von 7 Tagen.</li>
            <li>Sobald wir Ihre Zahlung erhalten haben, wird Ihre Bestellung versendet.</li>
            <li>Sie erhalten eine Versandbestätigung mit Tracking-Informationen.</li>
          </ol>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild className="bg-amber-500 hover:bg-amber-600">
            <Link href="/">Zurück zur Startseite</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/kontakt">Kontakt aufnehmen</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
