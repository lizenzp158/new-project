export function SeoSchema() {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "Randm Tornado Vapes",
          url: "https://randmtornadovapes.de",
          logo: "https://randmtornadovapes.de/logo.svg",
          sameAs: [
            "https://facebook.com/randmtornadovapes",
            "https://instagram.com/randmtornadovapes",
            "https://twitter.com/randmtornadovapes",
          ],
          contactPoint: {
            "@type": "ContactPoint",
            telephone: "+49-123-456789",
            contactType: "customer service",
            availableLanguage: "German",
          },
          address: {
            "@type": "PostalAddress",
            streetAddress: "Musterstraße 123",
            addressLocality: "Berlin",
            postalCode: "12345",
            addressCountry: "DE",
          },
        }),
      }}
    />
  )
}
